# Youtube-Video-Summarizer
This Application uses input Youtube URL to Extract text from the video. Then the extracted text will be used to create summary, top keywords, Sentiment analysis and keyframes.\

Follow me on Youtube - www.youtube.com/@WiseCoder-rp2zn
